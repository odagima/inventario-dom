import { useEffect, useMemo, useState } from 'react'
import * as XLSX from 'xlsx'
import { listarGruposAdmin, listarDatasContagemPorGrupo, buscarCMVSemanal, buscarContagensDoProduto, buscarVendasDoProduto } from '../lib/adminApi'
import { ultimoTrecho, formatarMoeda } from '../lib/formato'
import { useEscParaFechar } from '../lib/hooks'
import ArvoreDeOrigemView from '../components/ArvoreDeOrigemView'

// Busca por insumo (13/08/2026, pedido do Felipe — "buscar filet mignon" rápido dentro do grupo já
// calculado, sem acento/caixa importar) e destaque de proteínas (maiores diferenças em R$, pra dar
// pro chefe uma leitura rápida de onde o consumo mais desviou do esperado, sem precisar rolar a
// tabela toda).
const normalizarBusca = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase()
const LIMITE_DESTAQUE = 3
// 24/08/2026, pedido do Felipe: nova aba "Insumos-chave" (ver mais abaixo) — os insumos de maior
// peso em VALOR NA RECEITA, pra abrir o relatório direto na página sem precisar procurar na tabela
// inteira. Não é um ranking/top-N mostrado pro usuário (ele pediu explicitamente pra não aparecer
// número/posição) — é só um limite técnico de quantos botões oferecer.
const LIMITE_INSUMOS_CHAVE = 10

const num = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 })
const fmtDia = (d) => (d ? new Date(`${d}T00:00:00`).toLocaleDateString('pt-BR') : '—')
// NBSP entre "R$" e o número (não espaço normal) — evita quebra de linha no meio do valor
// em card/coluna estreita (mesmo fix aplicado em formato.js/formatarMoeda, 09/08/2026).
const fmtRS = (n) => n == null ? '—' : 'R$ ' + Number(n).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

function MemoriaCalculoFator({ fatorOrigem, fatorCorrecao, preparoIntermediario, percentualAproveitamentoRegistrado }) {
  if (fatorOrigem === 'direto') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        Contado direto como esse insumo — sem conversão de ficha técnica (o produto contado já é o insumo em natura).
      </p>
    )
  }
  if (fatorOrigem === 'calculado_via_preparo') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        ⚠ Fator recalculado via {preparoIntermediario ? `"${preparoIntermediario.nome}"` : 'preparo intermediário'} (ficha cadastrada zera a perda).
      </p>
    )
  }
  if (fatorOrigem === 'calculado') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        ⚠ Fator calculado (bruto ÷ líquido) — essa linha da ficha não tem "Fator"/"% aproveitamento" cadastrado no Everest.
        {fatorCorrecao === 1 && ' Deu exatamente 1: bruto = líquido cadastrados iguais — vale confirmar na ficha se esse insumo realmente não tem perda de limpeza nessa receita, ou se é uma lacuna de cadastro.'}
      </p>
    )
  }
  if (fatorOrigem === 'registrado') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        Fator cadastrado direto na ficha (coluna "Fator" do Everest){percentualAproveitamentoRegistrado != null ? ` · % aproveitamento cadastrado: ${num(percentualAproveitamentoRegistrado)}%` : ''}.
      </p>
    )
  }
  return (
    <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
      ⚠ Sem fator nem líquido cadastrado nessa linha da ficha — não deu pra calcular.
    </p>
  )
}

// 25/08/2026, pedido do Felipe: "gerar uma planilha simples mostrando como foi feito o cálculo" —
// pra ele conseguir auditar um insumo específico (ex.: filet mignon, 17/08 a 24/08) linha por linha,
// sem depender de mim rodar nada contra o banco ao vivo (este ambiente não tem acesso de rede ao
// Supabase — ver DECISOES-TRAVADAS.md). Gera na hora, no navegador, a partir dos mesmos dados já
// carregados na tela (nenhuma consulta nova) — mesma lib `xlsx` já usada na Exportação contábil.
// 3 abas: Resumo (os números finais), "Vendas (teórico)" (de qual prato veio cada pedaço do
// teórico) e "Contagem (real)" (quais produtos contados geraram o estoque inicial/final) — o mesmo
// detalhe que já existe nas abas Vendas/Contagem do relatório, só que em planilha, linha a linha.
function exportarMemoriaCalculo(item, dados) {
  const aoaResumo = [
    ['Memória de cálculo — CMV Real × Teórico'],
    [`Insumo: ${item.nome}`],
    [`Código Everest: ${item.codigoEverest}${item.subgrupoEverest ? ' · ' + ultimoTrecho(item.subgrupoEverest) : ''} · Unidade: ${item.unidade}`],
    [`Período: estoque inicial ${fmtDia(dados?.dataInicio)} (${dados?.sessoesInicio ?? '—'} sessão(ões)) → estoque final ${fmtDia(dados?.dataFim)} (${dados?.sessoesFim ?? '—'} sessão(ões))`],
    [],
    ['Campo', `Valor (${item.unidade})`],
    ['Estoque inicial', item.estoqueInicial],
    ['(+) Compras', item.compras],
    ['(-) Estoque final', item.estoqueFinal],
    ['(=) Real (consumido)', item.real],
    ['Teórico (esperado pelas fichas técnicas dos pratos vendidos)', item.teorico],
    ['Diferença (teórico − real)', item.diferenca],
    [],
    ['Custo unitário considerado (R$)', item.custoUnitario],
    ['Origem do custo', item.custoOrigem === 'compras' ? 'Média das compras desse insumo no período' : (item.custoOrigem === 'ficha' ? 'Ficha técnica mais recente' : '—')],
    ['Diferença em valor (R$)', item.diferencaValor],
    [],
    ['Como é calculado:'],
    ['Real = estoque inicial + compras no período − estoque final (tudo já convertido pro insumo em natura).'],
    ['Teórico = soma, de cada prato vendido no período que usa esse insumo, da quantidade que a ficha técnica do prato prevê consumir (ver aba "Vendas (teórico)").'],
    ['Diferença positiva = consumiu-se MENOS que o teórico previa (economia). Diferença negativa = consumiu-se MAIS (perda/quebra).']
  ]

  const aoaVendas = [
    ['De onde veio o TEÓRICO — pratos vendidos no período que usam esse insumo'],
    [],
    ['Prato', 'Código do prato', 'Qtd. vendida', `Qtd. bruta gerada (${item.unidade})`, `Qtd. líquida gerada (${item.unidade})`, 'Fator de correção', 'Origem do fator', '% do teórico', 'Valor estimado (R$)'],
    ...(item.pratos || []).map((p) => [
      p.nome, p.codigoPrato, p.quantidadeVendida, p.quantidadeInsumo, p.quantidadeLiquida,
      p.fatorCorrecao, p.fatorOrigem || '—', p.percentualDoTeorico, p.valorEstimado
    ])
  ]
  if (item.pratos?.length) {
    aoaVendas.push([])
    aoaVendas.push(['Total de TODOS os pratos (inclusive os que não vieram listados acima, se houver mais de 20)', '', '', item.teorico, item.pratosTotalLiquido])
    if (item.pratosOcultos > 0) aoaVendas.push([`+ ${item.pratosOcultos} prato(s) com menos peso, resumido(s) só no total acima — não listados linha a linha.`])
  } else {
    aoaVendas.push(['Nenhum prato vendido gerou consumo teórico desse insumo nesse período.'])
  }

  const aoaContagem = []
  for (const { campo, titulo, data } of [
    { campo: 'contagemInicial', titulo: 'Estoque inicial', data: dados?.dataInicio },
    { campo: 'contagemFinal', titulo: 'Estoque final', data: dados?.dataFim }
  ]) {
    const lista = item[campo] || []
    aoaContagem.push([`${titulo} — ${fmtDia(data)} (${lista.length} produto(s) contado(s))`])
    aoaContagem.push([])
    aoaContagem.push(['Produto contado', 'Código Everest', 'Qtd. contada', 'Unidade contada', `Qtd. bruta gerada (${item.unidade})`, `Qtd. líquida gerada (${item.unidade})`, 'Fator de correção', 'Origem do fator'])
    for (const p of lista) {
      aoaContagem.push([p.nome, p.codigoProduto, p.quantidadeContada, p.unidadeProduto, p.quantidadeGerada, p.quantidadeLiquidaGerada, p.fatorCorrecao, p.fatorOrigem || '—'])
    }
    if (lista.length === 0) aoaContagem.push(['Nenhum produto contado gerou esse insumo nesse levantamento.'])
    aoaContagem.push([])
  }

  const livro = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(livro, XLSX.utils.aoa_to_sheet(aoaResumo), 'Resumo')
  XLSX.utils.book_append_sheet(livro, XLSX.utils.aoa_to_sheet(aoaVendas), 'Vendas (teorico)')
  XLSX.utils.book_append_sheet(livro, XLSX.utils.aoa_to_sheet(aoaContagem), 'Contagem (real)')

  const nomeArquivo = String(item.nome || item.codigoEverest || 'insumo')
    .normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase()
  XLSX.writeFile(livro, `memoria-calculo-${nomeArquivo}-${dados?.dataInicio || ''}-a-${dados?.dataFim || ''}.xlsx`)
}

// 24/08/2026 — extraído do popup original pra virar reaproveitável: o mesmo relatório de detalhe
// (valores, diferença em R$, e as abas Vendas/Contagem de "de onde veio") agora é usado tanto
// dentro do popup (aba "Relatório completo", clique na tabela) quanto direto na página (aba "Top
// 10 por valor", sem popup — pedido explícito do Felipe: "o relatório vai ser igual ao popup que
// temos agora... mas agora é o relatório direto na página, sem ser popup"). `onFechar` só é
// passado por quem usa dentro de um popup — quando ausente, não mostra o "×" (não faz sentido
// "fechar" um relatório que já está direto na página).
function DetalheCMV({ item, dados, abaDetalhe, setAbaDetalhe, setDrill, onFechar }) {
  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
        <p style={{ margin: 0, fontWeight: 600, fontSize: 16 }}>{item.nome}</p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          <button onClick={() => exportarMemoriaCalculo(item, dados)} style={{ padding: '4px 10px', fontSize: 11.5 }}>
            Exportar memória de cálculo
          </button>
          {onFechar && <button onClick={onFechar} style={{ background: 'none', border: 'none', fontSize: 18 }}>×</button>}
        </div>
      </div>
      <p className="muted" style={{ margin: '4px 0 14px', fontSize: 12 }}>
        {item.unidade} · {item.codigoEverest}{item.subgrupoEverest ? ` · ${ultimoTrecho(item.subgrupoEverest)}` : ''}
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {[
          ['Estoque inicial', num(item.estoqueInicial)],
          ['Compras', num(item.compras)],
          ['Estoque final', num(item.estoqueFinal)],
          ['Real (consumido)', num(item.real)],
          ['Teórico (esperado pelas fichas)', num(item.teorico)]
        ].map(([rotulo, valor]) => (
          <div key={rotulo} style={{ display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 13 }}>
            <span className="muted">{rotulo}</span>
            <span style={{ fontWeight: 600, whiteSpace: 'nowrap', flexShrink: 0, fontVariantNumeric: 'tabular-nums' }}>{valor} {item.unidade}</span>
          </div>
        ))}

        <div style={{ borderTop: '1px solid var(--border)', marginTop: 4, paddingTop: 10, display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 13 }}>
          <span className="muted">Diferença (teórico − real)</span>
          <span style={{
            fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0, fontVariantNumeric: 'tabular-nums',
            color: item.diferenca > 0 ? 'var(--success)' : item.diferenca < 0 ? 'var(--danger)' : 'var(--text)'
          }}>
            {item.diferenca > 0 ? '+' : ''}{num(item.diferenca)} {item.unidade}
          </span>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 13 }}>
          <span className="muted">Diferença em valor</span>
          <span style={{
            fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0, fontVariantNumeric: 'tabular-nums',
            color: item.diferencaValor == null ? 'var(--text)' : item.diferencaValor > 0 ? 'var(--success)' : item.diferencaValor < 0 ? 'var(--danger)' : 'var(--text)'
          }}>
            {item.diferencaValor == null ? '—' : (item.diferencaValor > 0 ? '+' : '') + fmtRS(item.diferencaValor)}
          </span>
        </div>

        {item.custoUnitario != null ? (
          <p className="muted" style={{ margin: '2px 0 0', fontSize: 11 }}>
            Custo considerado: {fmtRS(item.custoUnitario)}/{item.unidade} ({item.custoOrigem === 'compras' ? 'média das compras desse insumo no período' : 'ficha técnica mais recente'}) ·
            diferença positiva = consumimos menos que o teórico (economia) · negativa = consumimos mais (perda, custou mais).
          </p>
        ) : (
          <p className="muted" style={{ margin: '2px 0 0', fontSize: 11 }}>
            Esse insumo não teve compra no período nem custo cadastrado numa ficha técnica — não dá pra converter a diferença em R$.
          </p>
        )}
      </div>

      {/* De onde veio (13/08/2026, pedido do Felipe — "mapear o que aconteceu com o filet
          mignon no período"): 2 abas dentro do relatório, a pedido do Felipe em 14/08/2026 (3)
          ("faça duas abas... vendas e a outra com os dados da contagem e a memória de
          cálculo... do mesmo jeito que está as vendas") — "Vendas" (de onde veio o TEÓRICO,
          olhando os pratos vendidos, já existia) e "Contagem" (de onde veio o REAL, olhando
          os produtos contados no estoque inicial/final). A memória de cálculo do fator de
          correção é a MESMA lógica nas 2 abas — extraída pro componente `MemoriaCalculoFator`
          (topo do arquivo) pra não duplicar. */}
      {(item.pratos?.length > 0 || item.contagemInicial?.length > 0 || item.contagemFinal?.length > 0) && (
        <div style={{ borderTop: '1px solid var(--border)', marginTop: 14, paddingTop: 12 }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
            {[['vendas', 'Vendas'], ['contagem', 'Contagem']].map(([chave, rotulo]) => (
              <button
                key={chave}
                onClick={() => setAbaDetalhe(chave)}
                style={{
                  flex: 1, padding: '6px 0', fontSize: 11.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.02em',
                  border: 'none', borderRadius: 6, cursor: 'pointer',
                  background: abaDetalhe === chave ? 'var(--accent)' : 'var(--surface-2)',
                  color: abaDetalhe === chave ? '#fff' : 'var(--muted)'
                }}
              >
                {rotulo}
              </button>
            ))}
          </div>

          {abaDetalhe === 'vendas' && (
            item.pratos && item.pratos.length > 0 ? (
              <>
                <p className="muted" style={{ margin: '0 0 8px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                  De onde veio o teórico ({item.pratos.length} prato{item.pratos.length > 1 ? 's' : ''})
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {item.pratos.map((p) => (
                    <div key={p.codigoPrato} style={{ background: 'var(--surface-2)', borderRadius: 8, padding: '8px 10px' }}>
                      <button
                        onClick={() => setDrill({ codigo: p.codigoPrato, nome: p.nome, modo: 'vendas' })}
                        style={{
                          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 10, fontSize: 12.5,
                          width: '100%', textAlign: 'left', background: 'none', border: 'none', padding: 0, cursor: 'pointer'
                        }}
                      >
                        <div style={{ minWidth: 0, overflow: 'hidden' }}>
                          <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.nome} <span className="muted" style={{ fontSize: 11 }}>→ ver vendas</span></div>
                          <div className="muted" style={{ fontSize: 11 }}>{num(p.quantidadeVendida)} vendido(s)</div>
                        </div>
                        <div style={{ textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap' }}>
                          {p.percentualDoTeorico != null && (
                            <div className="muted" style={{ fontSize: 11 }}>{num(p.percentualDoTeorico)}% do teórico</div>
                          )}
                          {p.valorEstimado != null && <div className="muted" style={{ fontSize: 11 }}>{fmtRS(p.valorEstimado)}</div>}
                        </div>
                      </button>
                      <div style={{ display: 'flex', gap: 14, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--border)' }}>
                        <div>
                          <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                          <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeLiquida)} {item.unidade}</div>
                        </div>
                        <div>
                          <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Fator correção</div>
                          <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{p.fatorCorrecao != null ? num(p.fatorCorrecao) : '—'}</div>
                        </div>
                        <div>
                          <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                          <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeInsumo)} {item.unidade}</div>
                        </div>
                      </div>
                      <MemoriaCalculoFator
                        fatorOrigem={p.fatorOrigem}
                        fatorCorrecao={p.fatorCorrecao}
                        preparoIntermediario={p.preparoIntermediario}
                        percentualAproveitamentoRegistrado={p.percentualAproveitamentoRegistrado}
                      />
                    </div>
                  ))}
                </div>
                {/* 17/08/2026 (3), pedido do Felipe: total somando TODOS os pratos (não só os
                    exibidos acima, que tem um limite de 20) — líquido é campo novo
                    (`pratosTotalLiquido`), bruto é o `teorico` que já existia (mesma soma). */}
                <div style={{ display: 'flex', gap: 14, marginTop: 10, paddingTop: 10, borderTop: '2px solid var(--border)' }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, flexShrink: 0 }}>Total</div>
                  <div>
                    <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                    <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(item.pratosTotalLiquido)} {item.unidade}</div>
                  </div>
                  <div>
                    <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                    <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(item.teorico)} {item.unidade}</div>
                  </div>
                </div>
                <p className="muted" style={{ margin: '8px 0 0', fontSize: 11 }}>
                  Líquido = o que de fato entra no prato · Fator de correção = bruto ÷ líquido (quanto comprar cru pra sobrar o líquido necessário) · Bruto = o que sai do estoque (já usado no Teórico acima).
                </p>
                {item.pratosOcultos > 0 && (
                  <p className="muted" style={{ margin: '4px 0 0', fontSize: 11 }}>
                    + {item.pratosOcultos} outro{item.pratosOcultos > 1 ? 's' : ''} prato{item.pratosOcultos > 1 ? 's' : ''} com menos peso, não mostrado{item.pratosOcultos > 1 ? 's' : ''} aqui.
                  </p>
                )}
              </>
            ) : (
              <p className="muted" style={{ fontSize: 12 }}>Nenhum prato vendido gerou consumo teórico desse insumo nesse período.</p>
            )
          )}

          {/* 14/08/2026 (3), pedido do Felipe — aba nova, espelhando a de Vendas: de onde veio
              o REAL (o que a contagem física registrou), separado em estoque inicial e final
              (as 2 datas exatas escolhidas no topo da tela), com a mesma memória de cálculo. */}
          {abaDetalhe === 'contagem' && (
            <>
              {/* 25/08/2026 (§32), pedido do Felipe: antes de listar produto por produto, o
                  confronto direto do próprio insumo — inicial × final × diferença × diferença em
                  R$. A diferença é (inicial − final): positiva = saiu do estoque no período.
                  Valorizada pelo mesmo custo unitário corrigido que o relatório já usa. */}
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5, marginBottom: 16 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    <th style={{ textAlign: 'left', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600 }}>Insumo</th>
                    <th style={{ textAlign: 'right', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>
                      Inicial<div style={{ fontWeight: 400, fontSize: 10 }}>{fmtDia(dados?.dataInicio)}</div>
                    </th>
                    <th style={{ textAlign: 'right', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>
                      Final<div style={{ fontWeight: 400, fontSize: 10 }}>{fmtDia(dados?.dataFim)}</div>
                    </th>
                    <th style={{ textAlign: 'right', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600 }}>Diferença</th>
                    <th style={{ textAlign: 'right', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600 }}>Diferença (R$)</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const dif = (item.estoqueInicial || 0) - (item.estoqueFinal || 0)
                    const difValor = item.custoUnitario != null ? dif * item.custoUnitario : null
                    return (
                      <tr>
                        <td style={{ padding: '8px', fontWeight: 600 }}>{item.nome}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(item.estoqueInicial)} {item.unidade}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(item.estoqueFinal)} {item.unidade}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap', fontWeight: 600 }}>{num(dif)} {item.unidade}</td>
                        <td style={{ padding: '8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap', fontWeight: 600 }}>
                          {difValor != null ? formatarMoeda(difValor) : '—'}
                        </td>
                      </tr>
                    )
                  })()}
                </tbody>
              </table>
              <p className="muted" style={{ margin: '-8px 0 14px', fontSize: 11 }}>
                Diferença = inicial − final (positiva = saiu do estoque no período). Valorizada pelo custo unitário
                corrigido{item.custoOrigem ? ` (${item.custoOrigem})` : ''}: {item.custoUnitario != null ? `${formatarMoeda(item.custoUnitario)} / ${item.unidade}` : 'sem custo conhecido'}.
                Isso é só o movimento de estoque — não desconta compras do período.
              </p>

              {[
                { campo: 'contagemInicial', titulo: 'Estoque inicial', data: dados?.dataInicio },
                { campo: 'contagemFinal', titulo: 'Estoque final', data: dados?.dataFim }
              ].map(({ campo, titulo, data }) => {
                const lista = item[campo] || []
                return (
                  <div key={campo} style={{ marginBottom: 14 }}>
                    <p className="muted" style={{ margin: '0 0 8px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                      {titulo} ({fmtDia(data)}) — {lista.length} produto{lista.length !== 1 ? 's' : ''} contado{lista.length !== 1 ? 's' : ''}
                    </p>
                    {lista.length === 0 ? (
                      <p className="muted" style={{ fontSize: 12 }}>Nenhum produto contado gerou esse insumo nesse levantamento.</p>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {lista.map((p) => (
                          <div key={p.codigoProduto} style={{ background: 'var(--surface-2)', borderRadius: 8, padding: '8px 10px' }}>
                            <button
                              onClick={() => setDrill({ codigo: p.codigoProduto, nome: p.nome, modo: 'contagens', data, titulo })}
                              style={{ display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
                            >
                              <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12.5 }}>{p.nome} <span className="muted" style={{ fontSize: 11 }}>→ ver contagens</span></div>
                            </button>
                            <div className="muted" style={{ fontSize: 11 }}>{num(p.quantidadeContada)} {p.unidadeProduto} contado(s)</div>
                            <div style={{ display: 'flex', gap: 14, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--border)' }}>
                              <div>
                                <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeLiquidaGerada)} {item.unidade}</div>
                              </div>
                              <div>
                                <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Fator correção</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{p.fatorCorrecao != null ? num(p.fatorCorrecao) : '—'}</div>
                              </div>
                              <div>
                                <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeGerada)} {item.unidade}</div>
                              </div>
                            </div>
                            <MemoriaCalculoFator
                              fatorOrigem={p.fatorOrigem}
                              fatorCorrecao={p.fatorCorrecao}
                              preparoIntermediario={p.preparoIntermediario}
                              percentualAproveitamentoRegistrado={null}
                            />
                          </div>
                        ))}
                        {/* 17/08/2026 (3), pedido do Felipe: total de líquido/bruto somando
                            todos os produtos contados desse campo (inicial e final ficam
                            separados, cada um com o próprio total — nada é truncado aqui,
                            então soma direto da lista já mostrada acima). */}
                        <div style={{ display: 'flex', gap: 14, marginTop: 4, paddingTop: 10, borderTop: '2px solid var(--border)' }}>
                          <div style={{ fontSize: 12.5, fontWeight: 600, flexShrink: 0 }}>Total</div>
                          <div>
                            <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                            <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                              {num(lista.reduce((soma, p) => soma + (Number(p.quantidadeLiquidaGerada) || 0), 0))} {item.unidade}
                            </div>
                          </div>
                          <div>
                            <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                            <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                              {num(lista.reduce((soma, p) => soma + (Number(p.quantidadeGerada) || 0), 0))} {item.unidade}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
              <p className="muted" style={{ margin: 0, fontSize: 11 }}>
                Estoque inicial/final = de onde veio o REAL (o que a contagem física registrou), já convertido pro insumo em natura — mesma lógica de bruto/líquido/fator de correção usada na aba Vendas.
              </p>
            </>
          )}
        </div>
      )}
    </>
  )
}

// 24/08/2026, pedido do Felipe — reformulado depois do primeiro retorno dele (era "Top 10 por
// valor", com 3 problemas apontados):
// 1) Nome da aba não podia sugerir ranking/contagem → agora "Insumos-chave".
// 2) Critério não pode ser o quanto foi de fato contado/comprado no período (`custoTotalReal`) —
//    isso é ruidoso pra insumo caro com pouco movimento físico no recorte (exemplo dele: filet
//    mignon não aparecia porque o real desse período específico deu baixo, mesmo sendo item
//    presente em toda contagem). O critério certo é o PESO EM VALOR NA RECEITA: usa
//    `custoTotalTeorico` (teórico das fichas dos pratos vendidos × custo unitário) — reflete
//    importância na composição dos pratos, não oscilação de estoque.
// 3) Não é uma lista numerada com valores ao lado — são botões pra escolher (só o nome, sem
//    número/posição/valor no botão), single-select. O relatório completo (valores, diferença etc.)
//    só aparece depois de escolher, no `DetalheCMV` abaixo.
// 25/08/2026, pedido do Felipe: rastrear de onde vem o número contado de um item — toda contagem
// registrada dele, com data, quem contou e quantidade, somando no fim. Substitui o "ver
// transformação" na aba Contagem (que ele avaliou como não fazendo sentido nesse contexto).
// 25/08/2026 (§32), pedido do Felipe: mesma ideia do "ver contagens", do lado das vendas.
// Agrupado por DIA — uma venda de restaurante gera dezenas de linhas por dia (uma por comanda);
// listar comanda a comanda seria ilegível e não ajudaria a conferir nada.
// 25/08/2026 (§32), pedido do Felipe ("achei um item que não apareceu no relatório... podemos
// fazer um double check?"). Reconciliação: de tudo que foi LIDO do banco no período, quanto entrou
// na conta e o que ficou de fora, com o motivo de cada descarte. Começa recolhido — é uma
// ferramenta de auditoria, não o conteúdo principal da tela.
function Conferencia({ conferencia }) {
  const [aberto, setAberto] = useState(false)
  if (!conferencia) return null

  const fontes = [
    { chave: 'contagem', rotulo: 'Contagem', unidadeRotulo: 'produtos contados', totalChave: 'produtosDistintos' },
    { chave: 'compras', rotulo: 'Compras', unidadeRotulo: 'produtos comprados', totalChave: 'produtosDistintos' },
    { chave: 'vendas', rotulo: 'Vendas', unidadeRotulo: 'pratos vendidos', totalChave: 'pratosDistintos' }
  ]
  const totalFora = fontes.reduce((a, f) => a + (conferencia[f.chave]?.descartados?.length || 0), 0)

  return (
    <div className="card" style={{ marginBottom: 16, borderColor: totalFora > 0 ? 'var(--warning, #C15A1B)' : 'var(--border)' }}>
      <button
        onClick={() => setAberto((v) => !v)}
        style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', background: 'none', border: 'none', padding: 0, cursor: 'pointer', textAlign: 'left' }}
        aria-expanded={aberto}
      >
        <span style={{ display: 'inline-block', transition: 'transform 150ms', transform: aberto ? 'rotate(90deg)' : 'none', fontSize: 10 }}>▶</span>
        <span style={{ fontWeight: 600, fontSize: 14 }}>Conferência dos dados</span>
        <span className="muted" style={{ fontSize: 12 }}>
          {totalFora === 0
            ? '— tudo que foi lido entrou na conta'
            : `— ${totalFora} ${totalFora === 1 ? 'item ficou' : 'itens ficaram'} de fora, com motivo`}
        </span>
      </button>

      {aberto && (
        <div style={{ marginTop: 14 }}>
          <p className="muted" style={{ margin: '0 0 12px', fontSize: 12 }}>
            Confere se algum item lido do banco deixou de entrar no cálculo. Ficar de fora nem sempre é erro
            (material de limpeza não vira insumo), mas nada some sem aparecer aqui.
          </p>

          {fontes.map((f) => {
            const c = conferencia[f.chave] || {}
            const descartados = c.descartados || []
            return (
              <div key={f.chave} style={{ marginBottom: 16 }}>
                <p style={{ margin: '0 0 6px', fontWeight: 600, fontSize: 13 }}>
                  {f.rotulo}
                  <span className="muted" style={{ fontWeight: 400, fontSize: 12 }}>
                    {' '}— {c.lidos || 0} lançamentos lidos · {c[f.totalChave] || 0} {f.unidadeRotulo} ·{' '}
                    <strong>{c.entraram || 0} entraram</strong>
                    {descartados.length > 0 && <> · {descartados.length} fora</>}
                  </span>
                </p>
                {descartados.length === 0 ? (
                  <p className="muted" style={{ margin: 0, fontSize: 12 }}>Nada ficou de fora.</p>
                ) : (
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                    <tbody>
                      {descartados.map((d, i) => (
                        <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                          <td style={{ padding: '5px 8px' }}>
                            {d.nome} <span className="muted">({d.codigo})</span>
                          </td>
                          <td style={{ padding: '5px 8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                            {Number(d.quantidade || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 })} {d.unidade || ''}
                          </td>
                          <td className="muted" style={{ padding: '5px 8px', fontSize: 11 }}>{d.motivo}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function VendasDoProduto({ codigo, dataInicio, dataFim }) {
  const [dados, setDados] = useState(null)
  const [erro, setErro] = useState('')
  const [soDoPeriodo, setSoDoPeriodo] = useState(true)

  useEffect(() => {
    let vivo = true
    setDados(null); setErro('')
    buscarVendasDoProduto(codigo, soDoPeriodo ? { dataInicio, dataFim } : {})
      .then((r) => { if (vivo) setDados(r) })
      .catch((e) => { if (vivo) setErro(e.message) })
    return () => { vivo = false }
  }, [codigo, soDoPeriodo, dataInicio, dataFim])

  const fq = (n) => Number(n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  const fd = (d) => (d ? new Date(`${String(d).slice(0, 10)}T00:00:00`).toLocaleDateString('pt-BR') : '—')

  if (erro) return <p style={{ color: 'var(--danger)', fontSize: 13 }}>{erro}</p>
  if (!dados) return <p className="muted" style={{ fontSize: 13 }}>Buscando vendas…</p>

  return (
    <div>
      <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, marginBottom: 10 }}>
        <input type="checkbox" checked={soDoPeriodo} onChange={(e) => setSoDoPeriodo(e.target.checked)} />
        <span>Só o período do relatório <span className="muted">({fd(dataInicio)} a {fd(dataFim)})</span></span>
      </label>

      {dados.linhas.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>Nenhuma venda registrada desse item nesse recorte.</p>
      ) : (
        <>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Dia', 'Loja', 'Qtd.', 'Valor'].map((h, i) => (
                  <th key={h} style={{ textAlign: i > 1 ? 'right' : 'left', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dados.linhas.map((l, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '6px 8px', whiteSpace: 'nowrap' }}>{fd(l.data)}</td>
                  <td style={{ padding: '6px 8px' }} className="muted">{l.loja || '—'}</td>
                  <td style={{ padding: '6px 8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{fq(l.quantidade)}</td>
                  <td style={{ padding: '6px 8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{formatarMoeda(l.valor)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={2} style={{ padding: '8px', fontWeight: 600 }}>Total · {dados.linhas.length} dia{dados.linhas.length !== 1 ? 's' : ''}</td>
                <td style={{ padding: '8px', textAlign: 'right', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{fq(dados.total)}</td>
                <td style={{ padding: '8px', textAlign: 'right', fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{formatarMoeda(dados.totalValor)}</td>
              </tr>
            </tfoot>
          </table>
          {dados.canceladas > 0 && (
            <p className="muted" style={{ margin: '10px 0 0', fontSize: 11 }}>
              {dados.canceladas} venda{dados.canceladas > 1 ? 's' : ''} cancelada{dados.canceladas > 1 ? 's' : ''} no período — fora do total acima, como em todo o resto do sistema.
            </p>
          )}
        </>
      )}
    </div>
  )
}

function ContagensDoProduto({ codigo, data, rotuloData, grupoId }) {
  const [dados, setDados] = useState(null)
  const [erro, setErro] = useState('')
  // 25/08/2026 (correção): o relatório NÃO usa um intervalo de datas — usa DOIS levantamentos em
  // datas específicas (estoque inicial e estoque final). Filtrar por intervalo trazia contagens de
  // dias intermediários que não entraram em conta nenhuma (ex.: o total dava 351,130 kg quando o
  // relatório usava 219,73 kg, porque o 24/08 entrava junto do 17/08). Agora o padrão é a data
  // EXATA do levantamento que foi clicado.
  const [soDessaData, setSoDessaData] = useState(true)

  useEffect(() => {
    let vivo = true
    setDados(null)
    setErro('')
    buscarContagensDoProduto(codigo, soDessaData && data ? { dataInicio: data, dataFim: data, grupoId } : {})
      .then((r) => { if (vivo) setDados(r) })
      .catch((e) => { if (vivo) setErro(e.message) })
    return () => { vivo = false }
  }, [codigo, soDessaData, data, grupoId])

  const fmtQtd = (n) => Number(n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })
  const fmtData = (d) => (d ? new Date(`${String(d).slice(0, 10)}T00:00:00`).toLocaleDateString('pt-BR') : '—')

  if (erro) return <p style={{ color: 'var(--danger)', fontSize: 13 }}>{erro}</p>
  if (!dados) return <p className="muted" style={{ fontSize: 13 }}>Buscando contagens…</p>

  return (
    <div>
      <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, marginBottom: 10 }}>
        <input type="checkbox" checked={soDessaData} onChange={(e) => setSoDessaData(e.target.checked)} disabled={!data} />
        <span>
          Só as contagens de {fmtData(data)}
          {rotuloData && <span className="muted"> ({rotuloData.toLowerCase()})</span>}
          <span className="muted"> — é o que o relatório usou</span>
        </span>
      </label>

      {dados.linhas.length === 0 ? (
        <p className="muted" style={{ fontSize: 13 }}>
          {dados.semProduto
            ? 'Esse item não está no cadastro atual de produtos.'
            : 'Nenhuma contagem registrada desse item nesse recorte.'}
        </p>
      ) : (
        <>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Data', 'Quem contou', 'Loja', 'Quantidade'].map((h, i) => (
                  <th key={h} style={{ textAlign: i === 3 ? 'right' : 'left', padding: '6px 8px', color: 'var(--muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dados.linhas.map((l, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '6px 8px', whiteSpace: 'nowrap' }}>{fmtData(l.data)}</td>
                  <td style={{ padding: '6px 8px' }}>{l.usuario}</td>
                  <td style={{ padding: '6px 8px' }}>{l.loja}</td>
                  <td style={{ padding: '6px 8px', textAlign: 'right', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                    {fmtQtd(l.quantidade)} {dados.produto?.unidade}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} style={{ padding: '8px', fontWeight: 600 }}>
                  Total · {dados.linhas.length} lançamento{dados.linhas.length !== 1 ? 's' : ''}
                </td>
                <td style={{ padding: '8px', textAlign: 'right', fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                  {fmtQtd(dados.total)} {dados.produto?.unidade}
                </td>
              </tr>
            </tfoot>
          </table>
          <p className="muted" style={{ margin: '10px 0 0', fontSize: 11 }}>
            Cada linha é um lançamento. O mesmo item contado duas vezes no mesmo dia aparece como duas linhas — é
            assim que se enxerga contagem em duplicidade.
          </p>
        </>
      )}
    </div>
  )
}

function PainelInsumosChave({ dados, itemSelecionado, selecionar, abaDetalhe, setAbaDetalhe, setDrill }) {
  const insumosChave = useMemo(() => {
    return dados.linhas
      .filter((l) => l.custoTotalTeorico != null && l.custoTotalTeorico > 0.01)
      .slice()
      .sort((a, b) => b.custoTotalTeorico - a.custoTotalTeorico)
      .slice(0, LIMITE_INSUMOS_CHAVE)
  }, [dados])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="card">
        <p className="muted" style={{ margin: '0 0 10px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
          Insumos-chave desse grupo
        </p>
        {insumosChave.length === 0 ? (
          <p className="muted" style={{ fontSize: 13 }}>Nenhum insumo com custo conhecido nesse período.</p>
        ) : (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {insumosChave.map((l) => {
              const ativo = itemSelecionado?.codigoEverest === l.codigoEverest
              return (
                <button
                  key={l.codigoEverest}
                  onClick={() => selecionar(l)}
                  style={{
                    border: 'none', borderRadius: 20, padding: '8px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer',
                    background: ativo ? 'var(--accent)' : 'var(--surface-2)', color: ativo ? '#fff' : 'var(--text)'
                  }}
                >
                  {l.nome}
                </button>
              )
            })}
          </div>
        )}
        <p className="muted" style={{ margin: '10px 0 0', fontSize: 11 }}>
          Insumos que mais pesam em valor na composição dos pratos vendidos nesse período — não é um ranking do que foi contado. Toque num item pra ver o relatório completo abaixo.
        </p>
      </div>

      {itemSelecionado && (
        <div className="card">
          <DetalheCMV item={itemSelecionado} dados={dados} abaDetalhe={abaDetalhe} setAbaDetalhe={setAbaDetalhe} setDrill={setDrill} onFechar={null} />
        </div>
      )}
    </div>
  )
}

export default function CMVSemanal() {
  const [grupos, setGrupos] = useState([])
  const [grupoId, setGrupoId] = useState('')
  const [datas, setDatas] = useState([])
  const [carregandoDatas, setCarregandoDatas] = useState(false)
  const [dataInicio, setDataInicio] = useState('')
  const [dataFim, setDataFim] = useState('')
  const [dados, setDados] = useState(null)
  const [calculando, setCalculando] = useState(false)
  const [erro, setErro] = useState('')
  const [subgrupoEverestFiltro, setSubgrupoEverestFiltro] = useState('')
  const [buscaInsumo, setBuscaInsumo] = useState('')
  const [popup, setPopup] = useState(null) // linha selecionada pro detalhe (aba "Relatório completo")
  // 24/08/2026, pedido do Felipe: a tela ganhou 2 abas de página (não confundir com as abas
  // Vendas/Contagem de dentro do relatório, que continuam existindo) — "Insumos-chave" (item
  // escolhido entre botões, relatório abre direto na página, sem popup) e "Relatório completo" (a
  // tabela inteira de sempre, com busca/filtro, e o relatório continua abrindo em popup ao clicar
  // numa linha — comportamento inalterado).
  const [abaPagina, setAbaPagina] = useState('chave')
  const [itemChave, setItemChave] = useState(null)
  // 14/08/2026 (3), pedido do Felipe: "de onde veio" ganhou 2 abas — Vendas (de onde veio o
  // TEÓRICO, já existia) e Contagem (de onde veio o REAL — estoque inicial/final). Sempre volta
  // pra "Vendas" quando abre um insumo novo, senão fica preso na aba do insumo anterior.
  const [abaDetalhe, setAbaDetalhe] = useState('vendas')
  // 20/08/2026, pedido do Felipe: dentro do "de onde vem" (Vendas/Contagem), poder clicar num
  // prato/produto específico (ex.: "DD PR ALIGOT COM FILET") e ver ELE MESMO se transformando de
  // volta no insumo em natura (mesmo motor da tela "Árvore de origem", §24 do doc de decisões) —
  // sem sair desse popup. `drill` guarda o código/nome do item escolhido; um 2º popup por cima
  // deste renderiza a árvore.
  const [drill, setDrill] = useState(null)

  useEscParaFechar(!!popup, () => setPopup(null))
  useEscParaFechar(!!drill, () => setDrill(null))

  function abrirDetalhe(l) {
    setAbaDetalhe('vendas')
    setDrill(null)
    setPopup(l)
  }

  function selecionarChave(l) {
    setAbaDetalhe('vendas')
    setDrill(null)
    setItemChave(l)
  }

  // Item "atual" pra fins de poda por foco na árvore de origem (§24.1) — depende de qual aba de
  // página está aberta, já que cada uma guarda sua própria seleção (`popup` vs `itemChave`).
  const itemEmFoco = abaPagina === 'chave' ? itemChave : popup

  useEffect(() => {
    // Só grupos ATIVOS aparecem aqui (24/08/2026, pedido do Felipe) — desativar um grupo em
    // Grupos.jsx some com ele desse filtro sem apagar o grupo nem suas contagens já feitas.
    listarGruposAdmin().then((lista) => setGrupos(lista.filter((g) => g.ativo))).catch(() => {})
  }, [])

  useEffect(() => {
    setDados(null)
    setDataInicio('')
    setDataFim('')
    if (!grupoId) { setDatas([]); return }
    setCarregandoDatas(true)
    listarDatasContagemPorGrupo(grupoId)
      .then((lista) => {
        setDatas(lista)
        // Lista vem do mais antigo pro mais novo — sugestão inicial: a data mais recente como
        // "fim", a anterior a ela como "início".
        if (lista.length) setDataFim(lista[lista.length - 1].data)
        if (lista.length > 1) setDataInicio(lista[lista.length - 2].data)
      })
      .catch((e) => setErro(e.message))
      .finally(() => setCarregandoDatas(false))
  }, [grupoId])

  async function calcular() {
    setErro(''); setCalculando(true)
    setSubgrupoEverestFiltro('') // novo cálculo pode ter um conjunto diferente de subgrupos — não mantém filtro de outra consulta
    setBuscaInsumo('')
    setItemChave(null)
    setPopup(null)
    try {
      setDados(await buscarCMVSemanal({ grupoId: grupoId || null, dataInicio: dataInicio || null, dataFim: dataFim || null }))
    } catch (e) {
      setErro(e.message)
    } finally {
      setCalculando(false)
    }
  }

  // Filtro "Subgrupo do Everest" — trocado de "Grupo" pra "Subgrupo" a pedido do Felipe (grupo é
  // muito genérico; subgrupo é mais específico, ex. "CARNES BOVINAS" em vez de só "CARNES"). Só
  // oferece os subgrupos que de fato aparecem no resultado dessa consulta (ex.: se a contagem só
  // tem itens de Proteínas/Secos/Alimentação Funcionário, só os subgrupos desses 3 aparecem pra
  // escolher) — não a lista inteira de subgrupos do Everest cadastrados na empresa toda.
  const opcoesSubgrupoEverest = useMemo(() => {
    if (!dados) return []
    const nomes = new Set(dados.linhas.map((l) => ultimoTrecho(l.subgrupoEverest)).filter(Boolean))
    return Array.from(nomes).sort((a, b) => a.localeCompare(b, 'pt-BR'))
  }, [dados])

  const linhasFiltradas = useMemo(() => {
    if (!dados) return []
    let linhas = dados.linhas
    if (subgrupoEverestFiltro) linhas = linhas.filter((l) => ultimoTrecho(l.subgrupoEverest) === subgrupoEverestFiltro)
    const busca = normalizarBusca(buscaInsumo)
    if (busca) linhas = linhas.filter((l) => normalizarBusca(l.nome).includes(busca) || normalizarBusca(l.codigoEverest).includes(busca))
    return linhas
  }, [dados, subgrupoEverestFiltro, buscaInsumo])

  // Destaque (13/08/2026, pedido do Felipe — "enfatizar a proteína"; 14/08/2026, corrigido a pedido
  // dele: o critério certo é IMPACTO NO CUSTO, não a diferença. "Nosso foco é analisar as
  // proteínas, que vão ser o item mais caro do prato" — uma proteína pode bater exatamente o
  // teórico (diferença ~0) e ainda ser, de longe, o insumo que mais pesa no custo do período; a
  // diferença some da lista por completo nesse caso, escondendo justamente o item mais caro.
  // Ranking agora por `custoTotalReal` (Real × custo unitário — o quanto esse insumo custou de
  // fato no período), não por `Math.abs(diferencaValor)`. Considera o conjunto já filtrado por
  // subgrupo/busca, mas ignora linhas sem custo conhecido (não dá pra ranquear sem custo).
  const destaques = useMemo(() => {
    return linhasFiltradas
      .filter((l) => l.custoTotalReal != null && l.custoTotalReal > 0.01)
      .slice()
      .sort((a, b) => b.custoTotalReal - a.custoTotalReal)
      .slice(0, LIMITE_DESTAQUE)
  }, [linhasFiltradas])

  return (
    <div>
      <div className="app-header" style={{ marginBottom: 10 }}>
        <p className="brand">CMV Real × Teórico</p>
        <p className="subtitle">
          Por insumo em natura, entre 2 datas exatas de contagem, dentro de 1 grupo de contagem (ex.: "Proteínas") —
          todas as lojas juntas, já que Compras não separa por loja no Everest. Real = estoque contado na data de
          início + compras no intervalo − estoque contado na data de fim. Teórico = fichas dos pratos vendidos no
          mesmo intervalo que usam algum insumo desse grupo. Conversão pro insumo em natura é automática (regra da
          folha — ver Consolidado da contagem), não depende mais de fator cadastrado manualmente.
        </p>
      </div>

      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
        <div>
          <label className="muted">Grupo de contagem</label>
          <select value={grupoId} onChange={(e) => setGrupoId(e.target.value)} style={{ width: '100%' }}>
            <option value="">Selecione…</option>
            {grupos.map((g) => <option key={g.id} value={g.id}>{g.nome}</option>)}
          </select>
        </div>
        <div>
          <label className="muted">Data de início (estoque do começo)</label>
          <select
            value={dataInicio}
            onChange={(e) => setDataInicio(e.target.value)}
            disabled={!grupoId || carregandoDatas || datas.length === 0}
            style={{ width: '100%' }}
          >
            <option value="">— nenhuma —</option>
            {datas.map((d) => (
              <option key={d.data} value={d.data}>{fmtDia(d.data)} · {d.totalSessoes} sessão(ões)</option>
            ))}
          </select>
        </div>
        <div>
          <label className="muted">Data de fim (estoque do fim)</label>
          <select
            value={dataFim}
            onChange={(e) => setDataFim(e.target.value)}
            disabled={!grupoId || carregandoDatas || datas.length === 0}
            style={{ width: '100%' }}
          >
            <option value="">— nenhuma —</option>
            {datas.map((d) => (
              <option key={d.data} value={d.data}>{fmtDia(d.data)} · {d.totalSessoes} sessão(ões)</option>
            ))}
          </select>
        </div>
        {erro && <p style={{ color: 'var(--danger)', fontSize: 13, margin: 0 }}>{erro}</p>}
        <button className="primary" onClick={calcular} disabled={calculando || !grupoId || (!dataInicio && !dataFim)}>
          {calculando ? 'Calculando…' : 'Calcular'}
        </button>
      </div>

      {dados && (
        <>
          {/* 24/08/2026, pedido do Felipe: abas de página — "Insumos-chave" (item escolhido entre
              botões, relatório completo abre direto aqui) e "Relatório completo" (tabela inteira +
              busca/filtro, popup ao clicar — igual já era antes). */}
          <div className="segmented" style={{ marginBottom: 16 }}>
            <button className={abaPagina === 'chave' ? 'active' : ''} onClick={() => setAbaPagina('chave')}>Insumos-chave</button>
            <button className={abaPagina === 'completo' ? 'active' : ''} onClick={() => setAbaPagina('completo')}>Relatório completo</button>
          </div>

          <p className="muted" style={{ marginBottom: 16, fontSize: 12 }}>
            Estoque inicial de {fmtDia(dados.dataInicio)} ({dados.sessoesInicio} sessão(ões)) · estoque final de {fmtDia(dados.dataFim)} ({dados.sessoesFim} sessão(ões)) ·
            compras e vendas consideradas de {fmtDia(dados.dataInicio)} a {fmtDia(dados.dataFim)}, restritas aos insumos desse grupo.
          </p>

          <Conferencia conferencia={dados.conferencia} />
        </>
      )}

      {dados && abaPagina === 'chave' && (
        <PainelInsumosChave
          dados={dados}
          itemSelecionado={itemChave}
          selecionar={selecionarChave}
          abaDetalhe={abaDetalhe}
          setAbaDetalhe={setAbaDetalhe}
          setDrill={setDrill}
        />
      )}

      {dados && abaPagina === 'completo' && (
        <>
          <div className="card" style={{ marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <label className="muted">Buscar insumo (ex.: "filet mignon")</label>
              <input
                type="text"
                value={buscaInsumo}
                onChange={(e) => setBuscaInsumo(e.target.value)}
                placeholder="Digite o nome ou código do insumo…"
                style={{ width: '100%' }}
              />
            </div>
            {opcoesSubgrupoEverest.length > 0 && (
              <div>
                <label className="muted">Filtrar por subgrupo do Everest (opcional)</label>
                <select value={subgrupoEverestFiltro} onChange={(e) => setSubgrupoEverestFiltro(e.target.value)} style={{ width: '100%' }}>
                  <option value="">Todos os subgrupos</option>
                  {opcoesSubgrupoEverest.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
            )}
          </div>

          {/* Destaque (ver comentário no useMemo `destaques`) — maiores IMPACTOS NO CUSTO do recorte
              atual (Real × custo unitário), não a diferença — pra dar uma leitura rápida de quais
              insumos mais pesam no bolso antes de ir pra tabela inteira. Some sozinho se não houver
              nenhum insumo com custo conhecido no recorte. */}
          {destaques.length > 0 && (
            <div className="card" style={{ marginBottom: 16 }}>
              <p className="muted" style={{ margin: '0 0 10px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                Maior impacto no custo {subgrupoEverestFiltro ? `· ${subgrupoEverestFiltro}` : buscaInsumo ? '· nesta busca' : 'do período'}
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {destaques.map((l) => (
                  <button
                    key={l.codigoEverest}
                    onClick={() => abrirDetalhe(l)}
                    style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, width: '100%',
                      textAlign: 'left', background: 'var(--surface-2)', border: 'none', borderRadius: 8,
                      padding: '10px 12px', fontSize: 13, cursor: 'pointer'
                    }}
                  >
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>{l.nome}</span>
                    <span style={{ textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap' }}>
                      <span style={{ display: 'block', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{fmtRS(l.custoTotalReal)}</span>
                      {l.diferencaValor != null && Math.abs(l.diferencaValor) > 0.01 && (
                        <span className="muted" style={{ fontSize: 11, color: l.diferencaValor > 0 ? 'var(--success)' : 'var(--danger)' }}>
                          {l.diferencaValor > 0 ? '+' : ''}{fmtRS(l.diferencaValor)} dif.
                        </span>
                      )}
                    </span>
                  </button>
                ))}
              </div>
              <p className="muted" style={{ margin: '10px 0 0', fontSize: 11 }}>
                Valor = quanto esse insumo custou de fato no período (Real × custo unitário) — critério de ordenação. "dif." é a diferença teórico−real desse insumo, só como referência (positiva/verde = economia, negativa/vermelho = perda). Toque pra ver o detalhe por prato.
              </p>
            </div>
          )}

          {linhasFiltradas.length === 0 ? (
            <p className="muted">
              {dados.linhas.length === 0
                ? 'Nenhum insumo em natura com movimento no período. Confere se há contagem/compras/vendas no intervalo escolhido.'
                : buscaInsumo
                  ? `Nenhum insumo bate com "${buscaInsumo}" — confere o nome ou tenta limpar a busca.`
                  : 'Nenhum insumo desse subgrupo do Everest no período — tenta "Todos os subgrupos" ou outro filtro.'}
            </p>
          ) : (
            <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
              <div style={{ minWidth: 560 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(5, 1fr)', gap: 0, fontSize: 11, fontWeight: 600, color: 'var(--muted)', padding: '10px 12px', borderBottom: '1px solid var(--border)' }}>
                  <span>Insumo em natura</span>
                  <span style={{ textAlign: 'right' }}>Est. inic.</span>
                  <span style={{ textAlign: 'right' }}>Compras</span>
                  <span style={{ textAlign: 'right' }}>Est. final</span>
                  <span style={{ textAlign: 'right' }}>Real</span>
                  <span style={{ textAlign: 'right' }}>Teórico</span>
                </div>
                {linhasFiltradas.map((l) => {
                  const desvio = l.diferenca
                  const cor = Math.abs(desvio) > Math.max(0.001, Math.abs(l.teorico) * 0.1) ? 'var(--danger)' : 'var(--text)'
                  return (
                    <button
                      key={l.codigoEverest}
                      onClick={() => abrirDetalhe(l)}
                      style={{
                        display: 'grid', gridTemplateColumns: '1.4fr repeat(5, 1fr)', gap: 0, width: '100%',
                        alignItems: 'center', textAlign: 'left', background: 'none', border: 'none',
                        borderBottom: '1px solid var(--border)', padding: '10px 12px', fontSize: 13, cursor: 'pointer'
                      }}
                    >
                      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden', gap: 2 }}>
                        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.nome}</span>
                        <span className="muted" style={{ fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {l.unidade} · {l.codigoEverest}{l.subgrupoEverest ? ` · ${ultimoTrecho(l.subgrupoEverest)}` : ''}
                        </span>
                      </div>
                      <span style={{ textAlign: 'right', color: 'var(--muted)', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.estoqueInicial)}</span>
                      <span style={{ textAlign: 'right', color: 'var(--muted)', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.compras)}</span>
                      <span style={{ textAlign: 'right', color: 'var(--muted)', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.estoqueFinal)}</span>
                      <span style={{ textAlign: 'right', fontWeight: 700, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.real)}</span>
                      <span style={{ textAlign: 'right', fontWeight: 700, color: cor, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.teorico)}</span>
                    </button>
                  )
                })}
              </div>
            </div>
          )}
          {linhasFiltradas.length > 0 && (
            <p className="muted" style={{ marginTop: 8, fontSize: 12 }}>
              Real e Teórico são quantidades de insumo em natura consumidas. Diferença grande (Real ≫ Teórico) = consumo
              acima do que as vendas justificam — perda, quebra ou porção fora do padrão. Toque num item pra ver o detalhe
              (estoque inicial/compras/final, e a diferença já em R$ — teórico menos real, então diferença negativa = perda).
            </p>
          )}

          {/* Popup detalhe do item — pedido do Felipe (09/08/2026): ver a estrutura completa (inicial,
              compras, final, real, teórico, diferença) e a diferença já convertida em R$.
              ⚠️ Convenção da diferença (corrigida em 09/08/2026, a pedido do Felipe): TEÓRICO − REAL, não
              o contrário — positiva = consumimos MENOS que o esperado (economia, verde); negativa =
              consumimos MAIS que o esperado (perda/quebra, vermelho). Mesma direção do "Consumo teórico ×
              Venda" em Análise de Custo.
              Custo unitário: preferência pro custo médio de COMPRA do próprio insumo no período (mais
              confiável — é o preço de fato pago, não um retrato antigo de alguma ficha); só cai pro custo
              da ficha técnica (a mais recente, quando o insumo tem custo em mais de uma) quando não teve
              compra direta no período. */}
          {popup && (
            <div onClick={() => setPopup(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 60, padding: 16 }}>
              <div className="card" style={{ maxWidth: 480, width: '100%', maxHeight: '85vh', overflowY: 'auto' }} onClick={(e) => e.stopPropagation()}>
                <DetalheCMV item={popup} dados={dados} abaDetalhe={abaDetalhe} setAbaDetalhe={setAbaDetalhe} setDrill={setDrill} onFechar={() => setPopup(null)} />
              </div>
            </div>
          )}
        </>
      )}

      {/* 20/08/2026, pedido do Felipe: popup por cima do popup — "ver transformação" de um
          prato/produto específico, mostrando a Árvore de Origem (§24 do doc de decisões) dele até
          o insumo em natura. Reaproveita o mesmo componente da tela "Árvore de origem", só embutido
          aqui pra não sair do contexto do CMV Semanal. `codigoFoco` usa o item que estiver aberto
          na aba de página ativa (Insumos-chave ou Relatório completo — ver `itemEmFoco`). */}
      {drill && (
        <div onClick={() => setDrill(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 70, padding: 16 }}>
          <div className="card" style={{ maxWidth: (drill.modo === 'contagens' || drill.modo === 'vendas') ? 640 : 520, width: '100%', maxHeight: '85vh', overflowY: 'auto' }} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ margin: 0, fontWeight: 600, fontSize: 15 }}>{drill.nome}</p>
                <p className="muted" style={{ margin: '2px 0 0', fontSize: 11 }}>
                  {drill.modo === 'contagens'
                    ? 'Todas as contagens registradas desse item'
                    : drill.modo === 'vendas'
                      ? 'Vendas registradas desse prato, por dia'
                      : 'Como esse item se transforma até o insumo em natura'}
                </p>
              </div>
              <button onClick={() => setDrill(null)} style={{ background: 'none', border: 'none', fontSize: 18 }}>×</button>
            </div>
            <div style={{ marginTop: 12 }}>
              {drill.modo === 'vendas' ? (
                <VendasDoProduto
                  codigo={drill.codigo}
                  dataInicio={dados?.dataInicio || null}
                  dataFim={dados?.dataFim || null}
                />
              ) : drill.modo === 'contagens' ? (
                <ContagensDoProduto
                  codigo={drill.codigo}
                  data={drill.data || null}
                  rotuloData={drill.titulo || null}
                  grupoId={grupoId || null}
                />
              ) : (
                <ArvoreDeOrigemView codigoEverest={drill.codigo} codigoFoco={itemEmFoco?.codigoEverest} />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
