import { useEffect, useMemo, useState } from 'react'
import { listarGruposAdmin, listarDatasContagemPorGrupo, buscarCMVSemanal } from '../lib/adminApi'
import { ultimoTrecho } from '../lib/formato'
import { useEscParaFechar } from '../lib/hooks'

// Busca por insumo (13/08/2026, pedido do Felipe — "buscar filet mignon" rápido dentro do grupo já
// calculado, sem acento/caixa importar) e destaque de proteínas (maiores diferenças em R$, pra dar
// pro chefe uma leitura rápida de onde o consumo mais desviou do esperado, sem precisar rolar a
// tabela toda).
const normalizarBusca = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase()
const LIMITE_DESTAQUE = 3

const num = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 })
const fmtDia = (d) => (d ? new Date(`${d}T00:00:00`).toLocaleDateString('pt-BR') : '—')
// NBSP entre "R$" e o número (não espaço normal) — evita quebra de linha no meio do valor
// em card/coluna estreita (mesmo fix aplicado em formato.js/formatarMoeda, 09/08/2026).
const fmtRS = (n) => n == null ? '—' : 'R$ ' + Number(n).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

function MemoriaCalculoFator({ fatorOrigem, fatorCorrecao, preparoIntermediario, percentualAproveitamentoRegistrado }) {
  if (fatorOrigem === 'direto') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        Contado direto como esse insumo — sem conversão de ficha técnica (o produto contado já é o insumo em natura).
      </p>
    )
  }
  if (fatorOrigem === 'calculado_via_preparo') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        ⚠ Fator recalculado via {preparoIntermediario ? `"${preparoIntermediario.nome}"` : 'preparo intermediário'} (ficha cadastrada zera a perda).
      </p>
    )
  }
  if (fatorOrigem === 'calculado') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        ⚠ Fator calculado (bruto ÷ líquido) — essa linha da ficha não tem "Fator"/"% aproveitamento" cadastrado no Everest.
        {fatorCorrecao === 1 && ' Deu exatamente 1: bruto = líquido cadastrados iguais — vale confirmar na ficha se esse insumo realmente não tem perda de limpeza nessa receita, ou se é uma lacuna de cadastro.'}
      </p>
    )
  }
  if (fatorOrigem === 'registrado') {
    return (
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
        Fator cadastrado direto na ficha (coluna "Fator" do Everest){percentualAproveitamentoRegistrado != null ? ` · % aproveitamento cadastrado: ${num(percentualAproveitamentoRegistrado)}%` : ''}.
      </p>
    )
  }
  return (
    <p className="muted" style={{ margin: '6px 0 0', fontSize: 10.5 }}>
      ⚠ Sem fator nem líquido cadastrado nessa linha da ficha — não deu pra calcular.
    </p>
  )
}

export default function CMVSemanal() {
  const [grupos, setGrupos] = useState([])
  const [grupoId, setGrupoId] = useState('')
  const [datas, setDatas] = useState([])
  const [carregandoDatas, setCarregandoDatas] = useState(false)
  const [dataInicio, setDataInicio] = useState('')
  const [dataFim, setDataFim] = useState('')
  const [dados, setDados] = useState(null)
  const [calculando, setCalculando] = useState(false)
  const [erro, setErro] = useState('')
  const [subgrupoEverestFiltro, setSubgrupoEverestFiltro] = useState('')
  const [buscaInsumo, setBuscaInsumo] = useState('')
  const [popup, setPopup] = useState(null) // linha selecionada pro detalhe
  // 14/08/2026 (3), pedido do Felipe: "de onde veio" ganhou 2 abas — Vendas (de onde veio o
  // TEÓRICO, já existia) e Contagem (de onde veio o REAL — estoque inicial/final). Sempre volta
  // pra "Vendas" quando abre um insumo novo, senão fica preso na aba do insumo anterior.
  const [abaDetalhe, setAbaDetalhe] = useState('vendas')

  useEscParaFechar(!!popup, () => setPopup(null))

  function abrirDetalhe(l) {
    setAbaDetalhe('vendas')
    setPopup(l)
  }

  useEffect(() => {
    listarGruposAdmin().then(setGrupos).catch(() => {})
  }, [])

  useEffect(() => {
    setDados(null)
    setDataInicio('')
    setDataFim('')
    if (!grupoId) { setDatas([]); return }
    setCarregandoDatas(true)
    listarDatasContagemPorGrupo(grupoId)
      .then((lista) => {
        setDatas(lista)
        // Lista vem do mais antigo pro mais novo — sugestão inicial: a data mais recente como
        // "fim", a anterior a ela como "início".
        if (lista.length) setDataFim(lista[lista.length - 1].data)
        if (lista.length > 1) setDataInicio(lista[lista.length - 2].data)
      })
      .catch((e) => setErro(e.message))
      .finally(() => setCarregandoDatas(false))
  }, [grupoId])

  async function calcular() {
    setErro(''); setCalculando(true)
    setSubgrupoEverestFiltro('') // novo cálculo pode ter um conjunto diferente de subgrupos — não mantém filtro de outra consulta
    setBuscaInsumo('')
    try {
      setDados(await buscarCMVSemanal({ grupoId: grupoId || null, dataInicio: dataInicio || null, dataFim: dataFim || null }))
    } catch (e) {
      setErro(e.message)
    } finally {
      setCalculando(false)
    }
  }

  // Filtro "Subgrupo do Everest" — trocado de "Grupo" pra "Subgrupo" a pedido do Felipe (grupo é
  // muito genérico; subgrupo é mais específico, ex. "CARNES BOVINAS" em vez de só "CARNES"). Só
  // oferece os subgrupos que de fato aparecem no resultado dessa consulta (ex.: se a contagem só
  // tem itens de Proteínas/Secos/Alimentação Funcionário, só os subgrupos desses 3 aparecem pra
  // escolher) — não a lista inteira de subgrupos do Everest cadastrados na empresa toda.
  const opcoesSubgrupoEverest = useMemo(() => {
    if (!dados) return []
    const nomes = new Set(dados.linhas.map((l) => ultimoTrecho(l.subgrupoEverest)).filter(Boolean))
    return Array.from(nomes).sort((a, b) => a.localeCompare(b, 'pt-BR'))
  }, [dados])

  const linhasFiltradas = useMemo(() => {
    if (!dados) return []
    let linhas = dados.linhas
    if (subgrupoEverestFiltro) linhas = linhas.filter((l) => ultimoTrecho(l.subgrupoEverest) === subgrupoEverestFiltro)
    const busca = normalizarBusca(buscaInsumo)
    if (busca) linhas = linhas.filter((l) => normalizarBusca(l.nome).includes(busca) || normalizarBusca(l.codigoEverest).includes(busca))
    return linhas
  }, [dados, subgrupoEverestFiltro, buscaInsumo])

  // Destaque (13/08/2026, pedido do Felipe — "enfatizar a proteína"; 14/08/2026, corrigido a pedido
  // dele: o critério certo é IMPACTO NO CUSTO, não a diferença. "Nosso foco é analisar as
  // proteínas, que vão ser o item mais caro do prato" — uma proteína pode bater exatamente o
  // teórico (diferença ~0) e ainda ser, de longe, o insumo que mais pesa no custo do período; a
  // diferença some da lista por completo nesse caso, escondendo justamente o item mais caro.
  // Ranking agora por `custoTotalReal` (Real × custo unitário — o quanto esse insumo custou de
  // fato no período), não por `Math.abs(diferencaValor)`. Considera o conjunto já filtrado por
  // subgrupo/busca, mas ignora linhas sem custo conhecido (não dá pra ranquear sem custo).
  const destaques = useMemo(() => {
    return linhasFiltradas
      .filter((l) => l.custoTotalReal != null && l.custoTotalReal > 0.01)
      .slice()
      .sort((a, b) => b.custoTotalReal - a.custoTotalReal)
      .slice(0, LIMITE_DESTAQUE)
  }, [linhasFiltradas])

  return (
    <div>
      <div className="app-header" style={{ marginBottom: 10 }}>
        <p className="brand">CMV Real × Teórico</p>
        <p className="subtitle">
          Por insumo em natura, entre 2 datas exatas de contagem, dentro de 1 grupo de contagem (ex.: "Proteínas") —
          todas as lojas juntas, já que Compras não separa por loja no Everest. Real = estoque contado na data de
          início + compras no intervalo − estoque contado na data de fim. Teórico = fichas dos pratos vendidos no
          mesmo intervalo que usam algum insumo desse grupo. Conversão pro insumo em natura é automática (regra da
          folha — ver Consolidado da contagem), não depende mais de fator cadastrado manualmente. Depois de calcular,
          dá pra buscar um insumo específico (ex.: "filet mignon"), ver os que mais desviaram em R$ em destaque, e
          abrir o detalhe de qualquer um pra ver de quais pratos veio o consumo teórico.
        </p>
      </div>

      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
        <div>
          <label className="muted">Grupo de contagem</label>
          <select value={grupoId} onChange={(e) => setGrupoId(e.target.value)} style={{ width: '100%' }}>
            <option value="">Selecione…</option>
            {grupos.map((g) => <option key={g.id} value={g.id}>{g.nome}</option>)}
          </select>
        </div>
        <div>
          <label className="muted">Data de início (estoque do começo)</label>
          <select
            value={dataInicio}
            onChange={(e) => setDataInicio(e.target.value)}
            disabled={!grupoId || carregandoDatas || datas.length === 0}
            style={{ width: '100%' }}
          >
            <option value="">— nenhuma —</option>
            {datas.map((d) => (
              <option key={d.data} value={d.data}>{fmtDia(d.data)} · {d.totalSessoes} sessão(ões)</option>
            ))}
          </select>
        </div>
        <div>
          <label className="muted">Data de fim (estoque do fim)</label>
          <select
            value={dataFim}
            onChange={(e) => setDataFim(e.target.value)}
            disabled={!grupoId || carregandoDatas || datas.length === 0}
            style={{ width: '100%' }}
          >
            <option value="">— nenhuma —</option>
            {datas.map((d) => (
              <option key={d.data} value={d.data}>{fmtDia(d.data)} · {d.totalSessoes} sessão(ões)</option>
            ))}
          </select>
        </div>
        {erro && <p style={{ color: 'var(--danger)', fontSize: 13, margin: 0 }}>{erro}</p>}
        <button className="primary" onClick={calcular} disabled={calculando || !grupoId || (!dataInicio && !dataFim)}>
          {calculando ? 'Calculando…' : 'Calcular'}
        </button>
      </div>

      {dados && (
        <div className="card" style={{ marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <label className="muted">Buscar insumo (ex.: "filet mignon")</label>
            <input
              type="text"
              value={buscaInsumo}
              onChange={(e) => setBuscaInsumo(e.target.value)}
              placeholder="Digite o nome ou código do insumo…"
              style={{ width: '100%' }}
            />
          </div>
          {opcoesSubgrupoEverest.length > 0 && (
            <div>
              <label className="muted">Filtrar por subgrupo do Everest (opcional)</label>
              <select value={subgrupoEverestFiltro} onChange={(e) => setSubgrupoEverestFiltro(e.target.value)} style={{ width: '100%' }}>
                <option value="">Todos os subgrupos</option>
                {opcoesSubgrupoEverest.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
          )}
        </div>
      )}

      {/* Destaque (ver comentário no useMemo `destaques`) — maiores IMPACTOS NO CUSTO do recorte
          atual (Real × custo unitário), não a diferença — pra dar uma leitura rápida de quais
          insumos mais pesam no bolso antes de ir pra tabela inteira. Some sozinho se não houver
          nenhum insumo com custo conhecido no recorte. */}
      {dados != null && destaques.length > 0 && (
        <div className="card" style={{ marginBottom: 16 }}>
          <p className="muted" style={{ margin: '0 0 10px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
            Maior impacto no custo {subgrupoEverestFiltro ? `· ${subgrupoEverestFiltro}` : buscaInsumo ? '· nesta busca' : 'do período'}
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {destaques.map((l) => (
              <button
                key={l.codigoEverest}
                onClick={() => abrirDetalhe(l)}
                style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, width: '100%',
                  textAlign: 'left', background: 'var(--surface-2)', border: 'none', borderRadius: 8,
                  padding: '10px 12px', fontSize: 13, cursor: 'pointer'
                }}
              >
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>{l.nome}</span>
                <span style={{ textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap' }}>
                  <span style={{ display: 'block', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{fmtRS(l.custoTotalReal)}</span>
                  {l.diferencaValor != null && Math.abs(l.diferencaValor) > 0.01 && (
                    <span className="muted" style={{ fontSize: 11, color: l.diferencaValor > 0 ? 'var(--success)' : 'var(--danger)' }}>
                      {l.diferencaValor > 0 ? '+' : ''}{fmtRS(l.diferencaValor)} dif.
                    </span>
                  )}
                </span>
              </button>
            ))}
          </div>
          <p className="muted" style={{ margin: '10px 0 0', fontSize: 11 }}>
            Valor = quanto esse insumo custou de fato no período (Real × custo unitário) — critério de ordenação. "dif." é a diferença teórico−real desse insumo, só como referência (positiva/verde = economia, negativa/vermelho = perda). Toque pra ver o detalhe por prato.
          </p>
        </div>
      )}

      {dados && (
        <p className="muted" style={{ marginBottom: 10, fontSize: 12 }}>
          Estoque inicial de {fmtDia(dados.dataInicio)} ({dados.sessoesInicio} sessão(ões)) · estoque final de {fmtDia(dados.dataFim)} ({dados.sessoesFim} sessão(ões)) ·
          compras e vendas consideradas de {fmtDia(dados.dataInicio)} a {fmtDia(dados.dataFim)}, restritas aos insumos desse grupo.
        </p>
      )}

      {dados != null && (
        linhasFiltradas.length === 0 ? (
          <p className="muted">
            {dados.linhas.length === 0
              ? 'Nenhum insumo em natura com movimento no período. Confere se há contagem/compras/vendas no intervalo escolhido.'
              : buscaInsumo
                ? `Nenhum insumo bate com "${buscaInsumo}" — confere o nome ou tenta limpar a busca.`
                : 'Nenhum insumo desse subgrupo do Everest no período — tenta "Todos os subgrupos" ou outro filtro.'}
          </p>
        ) : (
          <div className="card" style={{ padding: 0, overflowX: 'auto' }}>
            <div style={{ minWidth: 560 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(5, 1fr)', gap: 0, fontSize: 11, fontWeight: 600, color: 'var(--muted)', padding: '10px 12px', borderBottom: '1px solid var(--border)' }}>
                <span>Insumo em natura</span>
                <span style={{ textAlign: 'right' }}>Est. inic.</span>
                <span style={{ textAlign: 'right' }}>Compras</span>
                <span style={{ textAlign: 'right' }}>Est. final</span>
                <span style={{ textAlign: 'right' }}>Real</span>
                <span style={{ textAlign: 'right' }}>Teórico</span>
              </div>
              {linhasFiltradas.map((l) => {
                const desvio = l.diferenca
                const cor = Math.abs(desvio) > Math.max(0.001, Math.abs(l.teorico) * 0.1) ? 'var(--danger)' : 'var(--text)'
                return (
                  <button
                    key={l.codigoEverest}
                    onClick={() => abrirDetalhe(l)}
                    style={{
                      display: 'grid', gridTemplateColumns: '1.4fr repeat(5, 1fr)', gap: 0, width: '100%',
                      alignItems: 'center', textAlign: 'left', background: 'none', border: 'none',
                      borderBottom: '1px solid var(--border)', padding: '10px 12px', fontSize: 13, cursor: 'pointer'
                    }}
                  >
                    <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden', gap: 2 }}>
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.nome}</span>
                      <span className="muted" style={{ fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {l.unidade} · {l.codigoEverest}{l.subgrupoEverest ? ` · ${ultimoTrecho(l.subgrupoEverest)}` : ''}
                      </span>
                    </div>
                    <span style={{ textAlign: 'right', color: 'var(--muted)', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.estoqueInicial)}</span>
                    <span style={{ textAlign: 'right', color: 'var(--muted)', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.compras)}</span>
                    <span style={{ textAlign: 'right', color: 'var(--muted)', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.estoqueFinal)}</span>
                    <span style={{ textAlign: 'right', fontWeight: 700, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.real)}</span>
                    <span style={{ textAlign: 'right', fontWeight: 700, color: cor, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{num(l.teorico)}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )
      )}
      {dados != null && linhasFiltradas.length > 0 && (
        <p className="muted" style={{ marginTop: 8, fontSize: 12 }}>
          Real e Teórico são quantidades de insumo em natura consumidas. Diferença grande (Real ≫ Teórico) = consumo
          acima do que as vendas justificam — perda, quebra ou porção fora do padrão. Toque num item pra ver o detalhe
          (estoque inicial/compras/final, e a diferença já em R$ — teórico menos real, então diferença negativa = perda).
        </p>
      )}

      {/* Popup detalhe do item — pedido do Felipe (09/08/2026): ver a estrutura completa (inicial,
          compras, final, real, teórico, diferença) e a diferença já convertida em R$.
          ⚠️ Convenção da diferença (corrigida em 09/08/2026, a pedido do Felipe): TEÓRICO − REAL, não
          o contrário — positiva = consumimos MENOS que o esperado (economia, verde); negativa =
          consumimos MAIS que o esperado (perda/quebra, vermelho). Mesma direção do "Consumo teórico ×
          Venda" em Análise de Custo.
          Custo unitário: preferência pro custo médio de COMPRA do próprio insumo no período (mais
          confiável — é o preço de fato pago, não um retrato antigo de alguma ficha); só cai pro custo
          da ficha técnica (a mais recente, quando o insumo tem custo em mais de uma) quando não teve
          compra direta no período. */}
      {popup && (
        <div onClick={() => setPopup(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 60, padding: 16 }}>
          <div className="card" style={{ maxWidth: 480, width: '100%', maxHeight: '85vh', overflowY: 'auto' }} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <p style={{ margin: 0, fontWeight: 600, fontSize: 16 }}>{popup.nome}</p>
              <button onClick={() => setPopup(null)} style={{ background: 'none', border: 'none', fontSize: 18 }}>×</button>
            </div>
            <p className="muted" style={{ margin: '4px 0 14px', fontSize: 12 }}>
              {popup.unidade} · {popup.codigoEverest}{popup.subgrupoEverest ? ` · ${ultimoTrecho(popup.subgrupoEverest)}` : ''}
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                ['Estoque inicial', num(popup.estoqueInicial)],
                ['Compras', num(popup.compras)],
                ['Estoque final', num(popup.estoqueFinal)],
                ['Real (consumido)', num(popup.real)],
                ['Teórico (esperado pelas fichas)', num(popup.teorico)]
              ].map(([rotulo, valor]) => (
                <div key={rotulo} style={{ display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 13 }}>
                  <span className="muted">{rotulo}</span>
                  <span style={{ fontWeight: 600, whiteSpace: 'nowrap', flexShrink: 0, fontVariantNumeric: 'tabular-nums' }}>{valor} {popup.unidade}</span>
                </div>
              ))}

              <div style={{ borderTop: '1px solid var(--border)', marginTop: 4, paddingTop: 10, display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 13 }}>
                <span className="muted">Diferença (teórico − real)</span>
                <span style={{
                  fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0, fontVariantNumeric: 'tabular-nums',
                  color: popup.diferenca > 0 ? 'var(--success)' : popup.diferenca < 0 ? 'var(--danger)' : 'var(--text)'
                }}>
                  {popup.diferenca > 0 ? '+' : ''}{num(popup.diferenca)} {popup.unidade}
                </span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, fontSize: 13 }}>
                <span className="muted">Diferença em valor</span>
                <span style={{
                  fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0, fontVariantNumeric: 'tabular-nums',
                  color: popup.diferencaValor == null ? 'var(--text)' : popup.diferencaValor > 0 ? 'var(--success)' : popup.diferencaValor < 0 ? 'var(--danger)' : 'var(--text)'
                }}>
                  {popup.diferencaValor == null ? '—' : (popup.diferencaValor > 0 ? '+' : '') + fmtRS(popup.diferencaValor)}
                </span>
              </div>

              {popup.custoUnitario != null ? (
                <p className="muted" style={{ margin: '2px 0 0', fontSize: 11 }}>
                  Custo considerado: {fmtRS(popup.custoUnitario)}/{popup.unidade} ({popup.custoOrigem === 'compras' ? 'média das compras desse insumo no período' : 'ficha técnica mais recente'}) ·
                  diferença positiva = consumimos menos que o teórico (economia) · negativa = consumimos mais (perda, custou mais).
                </p>
              ) : (
                <p className="muted" style={{ margin: '2px 0 0', fontSize: 11 }}>
                  Esse insumo não teve compra no período nem custo cadastrado numa ficha técnica — não dá pra converter a diferença em R$.
                </p>
              )}
            </div>

            {/* De onde veio (13/08/2026, pedido do Felipe — "mapear o que aconteceu com o filet
                mignon no período"): 2 abas dentro do popup, a pedido do Felipe em 14/08/2026 (3)
                ("faça duas abas... vendas e a outra com os dados da contagem e a memória de
                cálculo... do mesmo jeito que está as vendas") — "Vendas" (de onde veio o TEÓRICO,
                olhando os pratos vendidos, já existia) e "Contagem" (de onde veio o REAL, olhando
                os produtos contados no estoque inicial/final). A memória de cálculo do fator de
                correção é a MESMA lógica nas 2 abas — extraída pro componente `MemoriaCalculoFator`
                (topo do arquivo) pra não duplicar. */}
            {(popup.pratos?.length > 0 || popup.contagemInicial?.length > 0 || popup.contagemFinal?.length > 0) && (
              <div style={{ borderTop: '1px solid var(--border)', marginTop: 14, paddingTop: 12 }}>
                <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                  {[['vendas', 'Vendas'], ['contagem', 'Contagem']].map(([chave, rotulo]) => (
                    <button
                      key={chave}
                      onClick={() => setAbaDetalhe(chave)}
                      style={{
                        flex: 1, padding: '6px 0', fontSize: 11.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.02em',
                        border: 'none', borderRadius: 6, cursor: 'pointer',
                        background: abaDetalhe === chave ? 'var(--accent)' : 'var(--surface-2)',
                        color: abaDetalhe === chave ? '#fff' : 'var(--muted)'
                      }}
                    >
                      {rotulo}
                    </button>
                  ))}
                </div>

                {abaDetalhe === 'vendas' && (
                  popup.pratos && popup.pratos.length > 0 ? (
                    <>
                      <p className="muted" style={{ margin: '0 0 8px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        De onde veio o teórico ({popup.pratos.length} prato{popup.pratos.length > 1 ? 's' : ''})
                      </p>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {popup.pratos.map((p) => (
                          <div key={p.codigoPrato} style={{ background: 'var(--surface-2)', borderRadius: 8, padding: '8px 10px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 10, fontSize: 12.5 }}>
                              <div style={{ minWidth: 0, overflow: 'hidden' }}>
                                <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.nome}</div>
                                <div className="muted" style={{ fontSize: 11 }}>{num(p.quantidadeVendida)} vendido(s)</div>
                              </div>
                              <div style={{ textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap' }}>
                                {p.percentualDoTeorico != null && (
                                  <div className="muted" style={{ fontSize: 11 }}>{num(p.percentualDoTeorico)}% do teórico</div>
                                )}
                                {p.valorEstimado != null && <div className="muted" style={{ fontSize: 11 }}>{fmtRS(p.valorEstimado)}</div>}
                              </div>
                            </div>
                            <div style={{ display: 'flex', gap: 14, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--border)' }}>
                              <div>
                                <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeLiquida)} {popup.unidade}</div>
                              </div>
                              <div>
                                <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Fator correção</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{p.fatorCorrecao != null ? num(p.fatorCorrecao) : '—'}</div>
                              </div>
                              <div>
                                <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                                <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeInsumo)} {popup.unidade}</div>
                              </div>
                            </div>
                            <MemoriaCalculoFator
                              fatorOrigem={p.fatorOrigem}
                              fatorCorrecao={p.fatorCorrecao}
                              preparoIntermediario={p.preparoIntermediario}
                              percentualAproveitamentoRegistrado={p.percentualAproveitamentoRegistrado}
                            />
                          </div>
                        ))}
                      </div>
                      {/* 17/08/2026 (3), pedido do Felipe: total somando TODOS os pratos (não só os
                          exibidos acima, que tem um limite de 20) — líquido é campo novo
                          (`pratosTotalLiquido`), bruto é o `teorico` que já existia (mesma soma). */}
                      <div style={{ display: 'flex', gap: 14, marginTop: 10, paddingTop: 10, borderTop: '2px solid var(--border)' }}>
                        <div style={{ fontSize: 12.5, fontWeight: 600, flexShrink: 0 }}>Total</div>
                        <div>
                          <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                          <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(popup.pratosTotalLiquido)} {popup.unidade}</div>
                        </div>
                        <div>
                          <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                          <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(popup.teorico)} {popup.unidade}</div>
                        </div>
                      </div>
                      <p className="muted" style={{ margin: '8px 0 0', fontSize: 11 }}>
                        Líquido = o que de fato entra no prato · Fator de correção = bruto ÷ líquido (quanto comprar cru pra sobrar o líquido necessário) · Bruto = o que sai do estoque (já usado no Teórico acima).
                      </p>
                      {popup.pratosOcultos > 0 && (
                        <p className="muted" style={{ margin: '4px 0 0', fontSize: 11 }}>
                          + {popup.pratosOcultos} outro{popup.pratosOcultos > 1 ? 's' : ''} prato{popup.pratosOcultos > 1 ? 's' : ''} com menos peso, não mostrado{popup.pratosOcultos > 1 ? 's' : ''} aqui.
                        </p>
                      )}
                    </>
                  ) : (
                    <p className="muted" style={{ fontSize: 12 }}>Nenhum prato vendido gerou consumo teórico desse insumo nesse período.</p>
                  )
                )}

                {/* 14/08/2026 (3), pedido do Felipe — aba nova, espelhando a de Vendas: de onde veio
                    o REAL (o que a contagem física registrou), separado em estoque inicial e final
                    (as 2 datas exatas escolhidas no topo da tela), com a mesma memória de cálculo. */}
                {abaDetalhe === 'contagem' && (
                  <>
                    {[
                      { campo: 'contagemInicial', titulo: 'Estoque inicial', data: dados?.dataInicio },
                      { campo: 'contagemFinal', titulo: 'Estoque final', data: dados?.dataFim }
                    ].map(({ campo, titulo, data }) => {
                      const lista = popup[campo] || []
                      return (
                        <div key={campo} style={{ marginBottom: 14 }}>
                          <p className="muted" style={{ margin: '0 0 8px', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                            {titulo} ({fmtDia(data)}) — {lista.length} produto{lista.length !== 1 ? 's' : ''} contado{lista.length !== 1 ? 's' : ''}
                          </p>
                          {lista.length === 0 ? (
                            <p className="muted" style={{ fontSize: 12 }}>Nenhum produto contado gerou esse insumo nesse levantamento.</p>
                          ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                              {lista.map((p) => (
                                <div key={p.codigoProduto} style={{ background: 'var(--surface-2)', borderRadius: 8, padding: '8px 10px' }}>
                                  <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12.5 }}>{p.nome}</div>
                                  <div className="muted" style={{ fontSize: 11 }}>{num(p.quantidadeContada)} {p.unidadeProduto} contado(s)</div>
                                  <div style={{ display: 'flex', gap: 14, marginTop: 6, paddingTop: 6, borderTop: '1px solid var(--border)' }}>
                                    <div>
                                      <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                                      <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeLiquidaGerada)} {popup.unidade}</div>
                                    </div>
                                    <div>
                                      <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Fator correção</div>
                                      <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{p.fatorCorrecao != null ? num(p.fatorCorrecao) : '—'}</div>
                                    </div>
                                    <div>
                                      <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                                      <div style={{ fontSize: 12.5, fontWeight: 600, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{num(p.quantidadeGerada)} {popup.unidade}</div>
                                    </div>
                                  </div>
                                  <MemoriaCalculoFator
                                    fatorOrigem={p.fatorOrigem}
                                    fatorCorrecao={p.fatorCorrecao}
                                    preparoIntermediario={p.preparoIntermediario}
                                    percentualAproveitamentoRegistrado={null}
                                  />
                                </div>
                              ))}
                              {/* 17/08/2026 (3), pedido do Felipe: total de líquido/bruto somando
                                  todos os produtos contados desse campo (inicial e final ficam
                                  separados, cada um com o próprio total — nada é truncado aqui,
                                  então soma direto da lista já mostrada acima). */}
                              <div style={{ display: 'flex', gap: 14, marginTop: 4, paddingTop: 10, borderTop: '2px solid var(--border)' }}>
                                <div style={{ fontSize: 12.5, fontWeight: 600, flexShrink: 0 }}>Total</div>
                                <div>
                                  <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Líquido</div>
                                  <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                                    {num(lista.reduce((soma, p) => soma + (Number(p.quantidadeLiquidaGerada) || 0), 0))} {popup.unidade}
                                  </div>
                                </div>
                                <div>
                                  <div className="muted" style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Bruto</div>
                                  <div style={{ fontSize: 12.5, fontWeight: 700, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
                                    {num(lista.reduce((soma, p) => soma + (Number(p.quantidadeGerada) || 0), 0))} {popup.unidade}
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    })}
                    <p className="muted" style={{ margin: 0, fontSize: 11 }}>
                      Estoque inicial/final = de onde veio o REAL (o que a contagem física registrou), já convertido pro insumo em natura — mesma lógica de bruto/líquido/fator de correção usada na aba Vendas.
                    </p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
